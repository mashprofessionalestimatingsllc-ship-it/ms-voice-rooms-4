import React, { useMemo, useState } from "react";
import {
  SafeAreaView, View, Text, StyleSheet, TouchableOpacity, ScrollView,
  TextInput, StatusBar, Modal
} from "react-native";

const C = {
  bg: "#100D18", panel: "#1B1527", panel2: "#241B35",
  purple: "#9B6BFF", purple2: "#7444D6", text: "#F7F2FF",
  muted: "#A99DBB", line: "#352846", green: "#51D6A0", pink: "#FF75C8"
};

const initialRooms = [
  { id: 1, title: "Late Night Chill 🎧", host: "Areeba", topic: "Music • Friends • Good vibes", seats: 14, category: "Chat", live: true, people: ["A","S","M","R"] },
  { id: 2, title: "English Speaking Club", host: "Hamza", topic: "Practice English together", seats: 8, category: "Learning", live: true, people: ["H","N","K"] },
  { id: 3, title: "Desi Beats & Requests", host: "Zoya", topic: "Your favourite songs", seats: 19, category: "Music", live: true, people: ["Z","A","F","U"] },
  { id: 4, title: "Make New Friends", host: "Danish", topic: "Meet positive people", seats: 5, category: "Chat", live: true, people: ["D","I"] },
];

const tabs = ["Discover", "Following", "Inbox", "Profile"];
const categories = ["All", "Chat", "Music", "Learning", "Gaming"];

function Avatar({ label, size = 42, color = C.purple2 }) {
  return <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }]}>
    <Text style={{ color: "white", fontWeight: "800", fontSize: size * .38 }}>{label}</Text>
  </View>;
}

function Pill({ children, active, onPress }) {
  return <TouchableOpacity onPress={onPress} style={[styles.pill, active && styles.pillActive]}>
    <Text style={[styles.pillText, active && { color: "white" }]}>{children}</Text>
  </TouchableOpacity>;
}

export default function App() {
  const [tab, setTab] = useState("Discover");
  const [category, setCategory] = useState("All");
  const [rooms] = useState(initialRooms);
  const [selected, setSelected] = useState(null);
  const [coins, setCoins] = useState(250);
  const [giftNotice, setGiftNotice] = useState("");
  const [search, setSearch] = useState("");
  const [following, setFollowing] = useState(["Areeba", "Zoya"]);

  const filtered = useMemo(() => rooms.filter(r =>
    (category === "All" || r.category === category) &&
    (r.title.toLowerCase().includes(search.toLowerCase()) || r.host.toLowerCase().includes(search.toLowerCase()))
  ), [rooms, category, search]);

  const sendGift = (gift, cost) => {
    if (coins < cost) { setGiftNotice("Not enough demo coins."); return; }
    setCoins(v => v - cost);
    setGiftNotice(`${gift} sent to ${selected?.host}!`);
  };

  const joinRoom = (room) => { setSelected(room); setGiftNotice(""); };

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={C.bg} />
    {selected ? (
      <View style={styles.screen}>
        <View style={styles.topbar}>
          <TouchableOpacity onPress={() => setSelected(null)}><Text style={styles.back}>‹ Back</Text></TouchableOpacity>
          <Text style={styles.live}>● LIVE</Text>
          <Text style={styles.coinSmall}>🪙 {coins}</Text>
        </View>
        <View style={styles.roomHero}>
          <Text style={styles.eyebrow}>MS VOICE ROOM</Text>
          <Text style={styles.roomTitle}>{selected.title}</Text>
          <Text style={styles.muted}>Hosted by {selected.host} · {selected.seats}/20 seats</Text>
          <View style={styles.roomBadge}><Text style={styles.roomBadgeText}>🎙 Voice preview mode — audio is simulated</Text></View>
        </View>
        <Text style={styles.sectionTitle}>On stage</Text>
        <View style={styles.stage}>
          {selected.people.map((p, i) => <View key={i} style={styles.stagePerson}>
            <View style={[styles.stageAvatar, { borderColor: i === 0 ? C.green : C.line }]}><Avatar label={p} size={54} color={["#7652C8","#A34D91","#426F9E","#9B654B"][i%4]} /></View>
            <Text style={styles.stageName}>{i === 0 ? selected.host : ["Sara","Mika","Rayan"][i-1] || "Guest"}</Text>
            <Text style={styles.mic}>{i === 0 ? "👑" : "🎤"}</Text>
          </View>)}
        </View>
        <Text style={styles.sectionTitle}>Room chat</Text>
        <ScrollView style={styles.chat} contentContainerStyle={{ gap: 12 }}>
          <Text style={styles.systemMsg}>Welcome! Be kind and respect everyone ✨</Text>
          <Text style={styles.chatLine}><Text style={styles.chatUser}>Sara: </Text>Hey everyone 👋</Text>
          <Text style={styles.chatLine}><Text style={styles.chatUser}>{selected.host}: </Text>Welcome to the room!</Text>
          <Text style={styles.chatLine}><Text style={styles.chatUser}>Mika: </Text>Good vibes only 💜</Text>
          {giftNotice ? <Text style={styles.systemMsg}>{giftNotice}</Text> : null}
        </ScrollView>
        <Text style={styles.sectionTitle}>Send a gift · demo coins</Text>
        <View style={styles.gifts}>
          {[["🌹",10],["❤️",25],["🎁",50],["👑",100]].map(([g,c]) =>
            <TouchableOpacity key={g} onPress={() => sendGift(g,c)} style={styles.giftButton}>
              <Text style={styles.giftEmoji}>{g}</Text><Text style={styles.giftCost}>{c} coins</Text>
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.roomActions}>
          <TouchableOpacity style={styles.actionButton}><Text style={styles.actionText}>🎤  Mic</Text></TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}><Text style={styles.actionText}>✋  Raise hand</Text></TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.leaveButton]} onPress={() => setSelected(null)}><Text style={styles.actionText}>Leave</Text></TouchableOpacity>
        </View>
      </View>
    ) : (
      <View style={styles.screen}>
        <View style={styles.header}>
          <View><Text style={styles.brand}>MS <Text style={{color:C.purple}}>VOICE</Text></Text><Text style={styles.tagline}>Your voice. Your room. Your community.</Text></View>
          <TouchableOpacity style={styles.coinPill} onPress={() => setCoins(v => v + 100)}><Text style={styles.coinText}>🪙 {coins}  +</Text></TouchableOpacity>
        </View>
        {tab === "Discover" ? <>
          <View style={styles.welcome}>
            <Text style={styles.welcomeTitle}>Find your people.</Text>
            <Text style={styles.muted}>Join a room and be part of the conversation.</Text>
          </View>
          <TextInput value={search} onChangeText={setSearch} placeholder="Search rooms or hosts..." placeholderTextColor={C.muted} style={styles.search} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{maxHeight:48}} contentContainerStyle={{gap:8}}>
            {categories.map(c => <Pill key={c} active={category===c} onPress={() => setCategory(c)}>{c}</Pill>)}
          </ScrollView>
          <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>Live rooms</Text><Text style={styles.muted}>20 seats max</Text></View>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{gap:12, paddingBottom:16}}>
            {filtered.map(room => <TouchableOpacity key={room.id} onPress={() => joinRoom(room)} style={styles.roomCard}>
              <View style={styles.cardTop}><Text style={styles.live}>● LIVE</Text><Text style={styles.seats}>👥 {room.seats}/20</Text></View>
              <Text style={styles.cardTitle}>{room.title}</Text>
              <Text style={styles.muted}>{room.topic}</Text>
              <View style={styles.cardBottom}>
                <View style={styles.hostRow}><Avatar label={room.host[0]} size={30}/><Text style={styles.hostName}>{room.host}</Text></View>
                <View style={styles.join}><Text style={styles.joinText}>Join room  ›</Text></View>
              </View>
            </TouchableOpacity>)}
            {filtered.length===0 && <Text style={styles.muted}>No rooms match your search.</Text>}
          </ScrollView>
        </> : tab === "Following" ? <>
          <Text style={styles.pageTitle}>Following</Text><Text style={styles.muted}>Hosts and friends you follow.</Text>
          {following.map(name => <View key={name} style={styles.followRow}><Avatar label={name[0]}/><View style={{flex:1}}><Text style={styles.hostName}>{name}</Text><Text style={styles.muted}>Creator · Voice rooms</Text></View><Text style={{color:C.green}}>Following</Text></View>)}
        </> : tab === "Inbox" ? <>
          <Text style={styles.pageTitle}>Inbox</Text><Text style={styles.muted}>Your messages and room notifications.</Text>
          {["Welcome to MS Voice Rooms!","Areeba invited you to Late Night Chill 🎧","Zoya is live now"].map((m,i)=><View key={i} style={styles.messageRow}><Avatar label={["M","A","Z"][i]}/><Text style={styles.chatLine}>{m}</Text></View>)}
        </> : <>
          <Text style={styles.pageTitle}>My profile</Text>
          <View style={styles.profileCard}><Avatar label="Y" size={76}/><Text style={styles.profileName}>Your profile</Text><Text style={styles.muted}>New member · MS Voice Rooms</Text><Text style={styles.coinText}>🪙 {coins} demo coins</Text></View>
          <TouchableOpacity style={styles.wideButton} onPress={() => setCoins(v=>v+100)}><Text style={styles.actionText}>＋ Add 100 demo coins</Text></TouchableOpacity>
          <Text style={styles.smallNote}>Coins and gifts are mock data for this preview. No payments are connected.</Text>
        </>}
        <View style={styles.tabbar}>{tabs.map(t => <TouchableOpacity key={t} onPress={() => setTab(t)} style={styles.tabItem}>
          <Text style={[styles.tabIcon, tab===t && {color:C.purple}]}>{({Discover:"⌂",Following:"♡",Inbox:"✉",Profile:"◉"})[t]}</Text>
          <Text style={[styles.tabLabel, tab===t && {color:C.text}]}>{t}</Text>
        </TouchableOpacity>)}</View>
      </View>
    )}
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:C.bg}, screen:{flex:1,paddingHorizontal:18,paddingTop:12},
  header:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:22},
  brand:{color:C.text,fontSize:24,fontWeight:"900",letterSpacing:1}, tagline:{color:C.muted,fontSize:10,marginTop:3},
  coinPill:{backgroundColor:C.panel2,borderWidth:1,borderColor:C.line,paddingVertical:9,paddingHorizontal:12,borderRadius:20},
  coinText:{color:"#F6D58A",fontWeight:"800"}, welcome:{marginBottom:16}, welcomeTitle:{color:C.text,fontSize:26,fontWeight:"800",marginBottom:5},
  muted:{color:C.muted,fontSize:12}, search:{backgroundColor:C.panel,borderColor:C.line,borderWidth:1,borderRadius:13,padding:13,color:C.text,marginBottom:14},
  pill:{paddingHorizontal:16,paddingVertical:9,borderRadius:20,backgroundColor:C.panel,borderWidth:1,borderColor:C.line},
  pillActive:{backgroundColor:C.purple2,borderColor:C.purple2},pillText:{color:C.muted,fontSize:12,fontWeight:"700"},
  sectionHeader:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginTop:18,marginBottom:10},
  sectionTitle:{color:C.text,fontSize:16,fontWeight:"800",marginTop:14,marginBottom:9},
  roomCard:{backgroundColor:C.panel,borderRadius:17,padding:15,borderWidth:1,borderColor:C.line},
  cardTop:{flexDirection:"row",justifyContent:"space-between",marginBottom:10},live:{color:C.green,fontSize:10,fontWeight:"900"},seats:{color:C.muted,fontSize:11},
  cardTitle:{color:C.text,fontSize:17,fontWeight:"800",marginBottom:5},cardBottom:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:14},
  hostRow:{flexDirection:"row",alignItems:"center",gap:8},hostName:{color:C.text,fontSize:12,fontWeight:"700"},
  join:{backgroundColor:C.purple2,borderRadius:20,paddingHorizontal:14,paddingVertical:8},joinText:{color:"white",fontSize:11,fontWeight:"800"},
  avatar:{alignItems:"center",justifyContent:"center",borderWidth:1,borderColor:"#FFFFFF22"},tabbar:{flexDirection:"row",justifyContent:"space-around",borderTopWidth:1,borderColor:C.line,paddingTop:10,paddingBottom:7,marginHorizontal:-18,backgroundColor:C.bg},
  tabItem:{alignItems:"center",minWidth:65},tabIcon:{color:C.muted,fontSize:21},tabLabel:{color:C.muted,fontSize:10,marginTop:3},
  pageTitle:{color:C.text,fontSize:25,fontWeight:"800",marginTop:12,marginBottom:5},followRow:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:15,borderBottomWidth:1,borderColor:C.line},
  messageRow:{flexDirection:"row",alignItems:"center",gap:12,paddingVertical:16,borderBottomWidth:1,borderColor:C.line},
  profileCard:{alignItems:"center",backgroundColor:C.panel,borderRadius:18,padding:24,marginTop:22,borderWidth:1,borderColor:C.line,gap:9},
  profileName:{color:C.text,fontWeight:"800",fontSize:20},wideButton:{backgroundColor:C.purple2,padding:14,borderRadius:13,alignItems:"center",marginTop:16},
  smallNote:{color:C.muted,fontSize:11,textAlign:"center",marginTop:12,lineHeight:17},
  topbar:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",paddingBottom:10},back:{color:C.text,fontSize:16,fontWeight:"700"},coinSmall:{color:"#F6D58A",fontWeight:"800"},
  roomHero:{backgroundColor:C.panel2,borderRadius:18,padding:20,marginTop:8,borderWidth:1,borderColor:C.line},
  eyebrow:{color:C.purple,fontSize:10,fontWeight:"900",letterSpacing:2},roomTitle:{color:C.text,fontSize:24,fontWeight:"900",marginVertical:8},
  roomBadge:{backgroundColor:"#35264D",padding:9,borderRadius:10,alignSelf:"flex-start",marginTop:13},roomBadgeText:{color:"#DCCBFF",fontSize:10},
  stage:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-around",backgroundColor:C.panel,borderRadius:16,padding:16,gap:14},
  stagePerson:{alignItems:"center",width:"25%"},stageAvatar:{borderWidth:2,borderRadius:40,padding:3},stageName:{color:C.text,fontSize:10,marginTop:6},mic:{fontSize:12,marginTop:3},
  chat:{backgroundColor:C.panel,borderRadius:13,padding:12,maxHeight:112},systemMsg:{color:C.purple,fontSize:11,fontWeight:"700"},chatLine:{color:C.text,fontSize:12},chatUser:{color:"#C6A9FF",fontWeight:"800"},
  gifts:{flexDirection:"row",justifyContent:"space-between",gap:7},giftButton:{flex:1,backgroundColor:C.panel2,borderRadius:12,alignItems:"center",paddingVertical:10,borderWidth:1,borderColor:C.line},
  giftEmoji:{fontSize:22},giftCost:{color:C.muted,fontSize:10,marginTop:4},roomActions:{flexDirection:"row",gap:7,marginTop:15},
  actionButton:{flex:1,backgroundColor:C.panel2,borderRadius:12,paddingVertical:13,alignItems:"center"},actionText:{color:C.text,fontSize:11,fontWeight:"800"},
  leaveButton:{backgroundColor:"#4B263F"},giftNotice:{color:C.green}
});
