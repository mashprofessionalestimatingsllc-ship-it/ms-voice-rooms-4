# MS Voice Rooms 4.0 — Expo MVP

A purple/black Expo + React Native UI prototype with mock data.

## Included
- Discover screen with room categories and search
- Mock live rooms (20-seat capacity shown)
- Room preview with stage avatars and mock chat
- Demo coin balance and gift buttons
- Following, Inbox, and Profile tabs
- Add-demo-coins interaction

## Run locally
1. Install Node.js (LTS).
2. In this folder run: `npm install`
3. Run: `npx expo start`
4. Install Expo Go on your phone and scan the QR code.

## Important
Voice is simulated in this MVP. No real audio, payments, account authentication,
or backend database is connected. Coins are local in-memory demo state and reset
when the app reloads. Before launch, add Firebase Auth/Firestore rules, moderation,
privacy controls, and a real voice provider.
